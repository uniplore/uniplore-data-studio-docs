#!/bin/bash

function checkSystem(){
  if [ "$(uname)" = "Darwin" ];
  then
    resultName='uniplore_http_ws_mac'
    resultFile='./uniplore_http_ws_mac'
  elif [ "$(expr substr $(uname -s) 1 5)" = "Linux" ];
  then
    resultName='uniplore_http_ws_linux'
    resultFile='./uniplore_http_ws_linux'
  fi
  # echo "$resultName"
}

function start(){
    nohup "$resultFile" >/dev/null 2>&1 &
}
function stop(){
    ps uxa|grep "$resultName"|grep -v grep|awk '{print $2}'|xargs kill
}
function checkStart(){
  ps uxa|grep "$resultName"|grep -v grep|awk '{print $2}'
}

checkSystem
if [ "$1" = "start" ];
then
  result=`ps uxa|grep "$resultName"|grep -v grep|awk '{print $2}'`
  if [ ! "$result" ];
  then
    start
    echo "进程开启成功..."
  else
    # echo "$result"
    echo "进程已存在,请不要重复开启..."
  fi
elif [ "$1" = "stop" ];
then
  stop
  echo "进程已关闭..."
elif [ "$1" = "restart" ];
then
  stop
  start
  echo "进程重新开启成功..."
fi
